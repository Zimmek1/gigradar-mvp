import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { MapPin, Music2, Search, CalendarDays, Radio, Sparkles, ExternalLink } from 'lucide-react';
import './style.css';

const SHOW_POSTS = [
  { source:'Facebook', text:'Friday night at Snug Harbor: The Low Pines w/ Carolina Ghost Notes. Doors 8pm. Indie folk / alt-country vibes.', venue:'Snug Harbor', city:'Charlotte, NC', date:'Fri Jun 12', lat:35.2204, lng:-80.8108, url:'#' },
  { source:'X', text:'TONIGHT: Neon Quarry brings synthy indie rock to Petra’s with opener Milk Glass Moon. 9pm.', venue:'Petra’s', city:'Charlotte, NC', date:'Tonight', lat:35.2174, lng:-80.8146, url:'#' },
  { source:'Threads', text:'Free show this Saturday at Salud Cerveceria: Blue Ridge Static and The County Line Kids. Americana, roots, country-rock.', venue:'Salud Cerveceria', city:'Charlotte, NC', date:'Sat Jun 13', lat:35.2479, lng:-80.8042, url:'#' },
  { source:'Facebook', text:'Amos’ Southend presents: Wax Chapel, Sunday Choir, and Paper Tigers. Emo/alt rock night. $12 adv.', venue:'Amos’ Southend', city:'Charlotte, NC', date:'Sun Jun 14', lat:35.2154, lng:-80.8556, url:'#' },
  { source:'X', text:'Evening Muse calendar update: Molly Everhart + Juniper Rodeo, songwriter folk night, Thursday.', venue:'The Evening Muse', city:'Charlotte, NC', date:'Thu Jun 11', lat:35.2472, lng:-80.8058, url:'#' },
  { source:'Threads', text:'Neighborhood Theatre: The Velvet Antlers headline with bright guitar pop and dancey indie hooks.', venue:'Neighborhood Theatre', city:'Charlotte, NC', date:'Fri Jun 19', lat:35.2477, lng:-80.8049, url:'#' },
  { source:'Facebook', text:'Tommy’s Pub: heavy local bill featuring Grave Picnic, Worn Teeth, and Brass Knuckle Velvet. Punk/garage.', venue:'Tommy’s Pub', city:'Charlotte, NC', date:'Sat Jun 20', lat:35.2366, lng:-80.8179, url:'#' }
];

const BAND_DB = {
  'The Low Pines': { genres:['indie folk','alt-country','americana'], similar:['Tyler Childers','Zach Bryan','Noah Kahan'], popularity:12 },
  'Carolina Ghost Notes': { genres:['bluegrass','americana','folk'], similar:['Billy Strings','Watchhouse','The Avett Brothers'], popularity:9 },
  'Neon Quarry': { genres:['indie rock','synth pop'], similar:['The 1975','Tame Impala','Phoenix'], popularity:14 },
  'Milk Glass Moon': { genres:['dream pop','indie pop'], similar:['Beach House','Alvvays','Men I Trust'], popularity:8 },
  'Blue Ridge Static': { genres:['country rock','americana'], similar:['Turnpike Troubadours','Whiskey Myers','Zach Bryan'], popularity:11 },
  'The County Line Kids': { genres:['roots rock','southern rock'], similar:['Jason Isbell','Drive-By Truckers','Chris Stapleton'], popularity:10 },
  'Wax Chapel': { genres:['emo','alternative rock'], similar:['Paramore','Jimmy Eat World','Modern Baseball'], popularity:15 },
  'Sunday Choir': { genres:['alt rock','indie rock'], similar:['The Killers','Death Cab for Cutie','Manchester Orchestra'], popularity:13 },
  'Paper Tigers': { genres:['pop punk','emo'], similar:['Blink-182','Fall Out Boy','Paramore'], popularity:10 },
  'Molly Everhart': { genres:['singer-songwriter','folk'], similar:['Phoebe Bridgers','Noah Kahan','Kacey Musgraves'], popularity:7 },
  'Juniper Rodeo': { genres:['folk rock','americana'], similar:['The Lumineers','Caamp','Mt. Joy'], popularity:8 },
  'The Velvet Antlers': { genres:['indie pop','indie rock'], similar:['Vampire Weekend','The Strokes','Peach Pit'], popularity:12 },
  'Grave Picnic': { genres:['garage punk','punk rock'], similar:['IDLES','Viagra Boys','The Chats'], popularity:6 },
  'Worn Teeth': { genres:['hardcore punk','garage rock'], similar:['Turnstile','FIDLAR','PUP'], popularity:7 },
  'Brass Knuckle Velvet': { genres:['garage rock','punk'], similar:['White Reaper','The Hives','Amyl and the Sniffers'], popularity:6 }
};

const USER_HOME = { lat:35.5849, lng:-80.8101 }; // Mooresville-ish default

function miles(a,b){ const R=3958.8; const toRad=d=>d*Math.PI/180; const dLat=toRad(b.lat-a.lat), dLng=toRad(b.lng-a.lng); const s=Math.sin(dLat/2)**2+Math.cos(toRad(a.lat))*Math.cos(toRad(b.lat))*Math.sin(dLng/2)**2; return R*2*Math.atan2(Math.sqrt(s),Math.sqrt(1-s)); }
function extractBands(text){ const names=Object.keys(BAND_DB); return names.filter(n => text.toLowerCase().includes(n.toLowerCase())); }
function tokenize(s){ return s.toLowerCase().split(/[,\n]+/).map(x=>x.trim()).filter(Boolean); }
function scoreBand(band, favorites){ const data=BAND_DB[band]; const favs=tokenize(favorites); if(!favs.length) return 45; let score=0; for(const fav of favs){ if(data.similar.some(a=>a.toLowerCase().includes(fav)||fav.includes(a.toLowerCase()))) score += 34; if(data.genres.some(g=>fav.includes(g)||g.includes(fav))) score += 22; const genreHints={zach:'americana',tyler:'alt-country',turnpike:'country rock',noah:'folk',paramore:'emo',phoebe:'singer-songwriter',tame:'synth pop',strokes:'indie rock',billy:'bluegrass'}; Object.entries(genreHints).forEach(([hint, genre])=>{ if(fav.includes(hint) && data.genres.includes(genre)) score += 24; }); }
 return Math.min(99, Math.round(35 + score + Math.max(0, 12-data.popularity)/2)); }
function reason(band, favorites){ const data=BAND_DB[band]; const favs=tokenize(favorites); const sim = data.similar.find(a => favs.some(f=>a.toLowerCase().includes(f)||f.includes(a.toLowerCase()))) || data.similar[0]; return `Similar to ${sim}; ${data.genres.slice(0,2).join(' / ')}.`; }

function App(){
 const [favorites,setFavorites]=useState('Zach Bryan, Tyler Childers, Noah Kahan');
 const [radius,setRadius]=useState(50);
 const [activeSources,setActiveSources]=useState(['Facebook','X','Threads']);
 const toggleSource=s=>setActiveSources(v=>v.includes(s)?v.filter(x=>x!==s):[...v,s]);
 const recs=useMemo(()=>{
   return SHOW_POSTS.filter(p=>activeSources.includes(p.source)).flatMap(post=>extractBands(post.text).map(band=>{
     const distance=miles(USER_HOME,{lat:post.lat,lng:post.lng});
     return {band, post, distance, score:scoreBand(band,favorites), reason:reason(band,favorites), genres:BAND_DB[band].genres, similar:BAND_DB[band].similar};
   })).filter(r=>r.distance<=radius).sort((a,b)=> a.distance-b.distance || b.score-a.score);
 },[favorites,radius,activeSources]);
 return <div className="app">
  <header className="hero"><div><p className="eyebrow"><Radio size={16}/> local discovery MVP</p><h1>GigRadar</h1><p>Find unknown local shows you’d actually like, sorted by distance.</p></div><div className="heroCard"><Sparkles/><b>{recs.length}</b><span>matches found</span></div></header>
  <section className="panel controls"><label><Music2 size={18}/> Favorite artists or genres<textarea value={favorites} onChange={e=>setFavorites(e.target.value)} placeholder="Zach Bryan, Paramore, indie folk..." /></label><label><MapPin size={18}/> Max distance: {radius} miles<input type="range" min="5" max="80" value={radius} onChange={e=>setRadius(+e.target.value)} /></label><div className="chips">{['Facebook','X','Threads'].map(s=><button className={activeSources.includes(s)?'chip on':'chip'} onClick={()=>toggleSource(s)} key={s}>{s}</button>)}</div></section>
  <main className="grid"><section><h2><Search size={20}/> Who to go see</h2>{recs.map((r,i)=><article className="card" key={r.band+r.post.venue}><div className="rank">#{i+1}</div><div className="cardTop"><div><h3>{r.band}</h3><p>{r.reason}</p></div><div className="score">{r.score}%<span>match</span></div></div><div className="tags">{r.genres.map(g=><span key={g}>{g}</span>)}</div><div className="meta"><span><CalendarDays size={15}/>{r.post.date}</span><span><MapPin size={15}/>{r.post.venue} · {r.distance.toFixed(1)} mi</span><span>{r.post.source}</span></div><details><summary>Show source post</summary><p>{r.post.text}</p></details></article>)}</section>
  <aside className="panel"><h2>Connector plan</h2><ol><li>Collect posts from official APIs, venue calendars, Eventbrite, RSS, or approved data providers.</li><li>Extract band names with rules + AI cleanup.</li><li>Search Spotify artist catalog for genres/images/URLs.</li><li>Compare user taste to band genres/similar artists.</li><li>Rank by distance first, then taste match.</li></ol><p className="note">This prototype uses sample Charlotte-area-style posts so the product can be tested without API keys.</p></aside></main>
 </div>
}

createRoot(document.getElementById('root')).render(<App/>);
